#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/opt/jeylabs/lib"
XML2_LIBS="-lxml2 -L/opt/jeylabs/lib -lz     -lm "
XML2_INCLUDEDIR="-I/opt/jeylabs/include/libxml2"
MODULE_VERSION="xml2-2.9.9"

